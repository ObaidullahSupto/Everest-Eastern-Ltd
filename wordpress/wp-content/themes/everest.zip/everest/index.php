<!DOCTYPE html>
<html <?php language_attributes(); global $eel; ?>>

	<head>
		<!-- Meta -->
		<meta charset="<?php bloginfo('charset');?>">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
		<link rel="shortcut icon" href="<?php echo get_template_directory_uri();?>/assets/img/EEL.jpg">
		<?php wp_head();?>
	</head>
	
    <body data-spy="scroll" data-target=".navbar" data-offset="80" style="overflow-x: hidden; ">

			
		
		<!-- START NAVBAR -->
		<div id="sticker" class="navbar navbar-default navbar-fixed-top menu-top">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
						<span class="sr-only">Toggle navigation</span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span> 
				    </button>				
					<a href="<?php echo site_url();?>" class="navbar-brand"><img src="<?php  echo $eel['site_logo']['url'];?> " alt="logo"></a>
					<img src="<?php echo get_template_directory_uri();?>/assets/img/data.jpg" alt="title">
				</div>
				 <div class="collapse navbar-collapse" id="myNavbar">
					<nav>
						<?php wp_nav_menu(array
							('theme_location'=>'primary_menu',
							 'fallback_cb'=>'everest_fallback_menu',
							 'container'=>'',
							 'menu_class'=>'nav navbar-nav pull-right',
							
							)
						   );
						?>
					</nav>
				</div> 
			</div><!--- END CONTAINER -->
		</div> 
		<!-- END NAVBAR -->
		
		 <!-- START HOME -->
		<section id="home" class="welcome-area section-top-50 section-lg-0">
            <div class="back">
				<div class="owl-carousel-wrap text-center wrap-fluid">
					<div data-items="1" data-sm-items="2" data-md-items="3" data-lg-items="4" data-xl-items="5" data-stage-padding="0" data-loop="true" data-margin="15" data-mouse-drag="true" data-autoplay="false" 		data-dots="true" data-nav-custom=".owl-custom-navigation" class="owl-carousel">
						<div class="owl-item">
							<div class="product"><img src="<?php echo get_template_directory_uri();?>/assets/img/slider/5.jpg" alt="" width="280" height="280">
								<div class="product-content">
									<div class="small">FarEast Islami Life Insurance Co. Ltd</div>
								</div>
						   </div>
						</div>
						 
						<div class="owl-item">
								<div class="product"><img src="<?php echo get_template_directory_uri();?>/assets/img/slider/1.jpg" alt="" width="280" height="280">
									<div class="product-content">
										<div class="small">BGMEA DHAKA</div>
									</div>
							   </div>
						</div>
						<div class="owl-item">
								<div class="product"><img src="<?php echo get_template_directory_uri();?>/assets/img/slider/2.jpg" alt="" width="280" height="280">
									<div class="product-content">
										<div class="small">National Sports Council</div>
									</div>
							   </div>
						</div>
						<div class="owl-item">
								<div class="product"><img src="<?php echo get_template_directory_uri();?>/assets/img/slider/3.jpg" alt="" width="280" height="280">
									<div class="product-content">
										<div class="small">Basundhara Gym Complex</div>
									</div>
							   </div>
						</div>
						<div class="owl-item">
								<div class="product"><img src="<?php echo get_template_directory_uri();?>/assets/img/slider/15.jpg" alt="" width="280" height="280">
									<div class="product-content">
										<div class="small">Shahabuddin Medical College</div>
									</div>
							   </div>
						</div>
						<div class="owl-item">
								<div class="product"><img src="<?php echo get_template_directory_uri();?>/assets/img/slider/16.jpg" alt="" width="280" height="280">
									<div class="product-content">
										<div class="small">BIRDEM (Ibrahim Memorial Hospital)</div>
									</div>
							   </div>
						</div>
						<div class="owl-item">
								<div class="product"><img src="<?php echo get_template_directory_uri();?>/assets/img/slider/17.jpg" alt="" width="280" height="280">
									<div class="product-content">
										<div class="small">DU Tower Building</div>
									</div>
							   </div>
						</div>
						<div class="owl-item">
								<div class="product"><img src="<?php echo get_template_directory_uri();?>/assets/img/slider/18.jpg" alt="" width="280" height="280">
									<div class="product-content">
										<div class="small">BUET Teachers Quater</div>
									</div>
							   </div>
						</div>
						<div class="owl-item">
								<div class="product"><img src="<?php echo get_template_directory_uri();?>/assets/img/slider/24.jpg" alt="" width="280" height="280">
									<div class="product-content">
										<div class="small">Adamjee Anex Bhavan</div>
									</div>
							   </div>
						</div>
						<div class="owl-item">
								<div class="product"><img src="<?php echo get_template_directory_uri();?>/assets/img/slider/on12.jpg" alt="" width="280" height="280">
									<div class="product-content">
										<div class="small">Concord Modhumoti2</div>
									</div>
							   </div>
						</div>
						<div class="owl-item">
								<div class="product"><img src="<?php echo get_template_directory_uri();?>/assets/img/slider/31.jpg" alt="" width="280" height="280">
									<div class="product-content">
										<div class="small">Star Tower</div>
									</div>
							   </div>
						</div>
						<div class="owl-item">
								<div class="product"><img src="<?php echo get_template_directory_uri();?>/assets/img/slider/35.jpg" alt="" width="280" height="280">
									<div class="product-content">
										<div class="small">EAST WEST UNIVERSITY</div>
									</div>
							   </div>
						</div>
						<div class="owl-item">
								<div class="product"><img src="<?php echo get_template_directory_uri();?>/assets/img/slider/36.jpg" alt="" width="280" height="280">
									<div class="product-content">
										<div class="small">NCC Bank Bhabon</div>
									</div>
							   </div>
						</div>
						<div class="owl-item">
								<div class="product"><img src="<?php echo get_template_directory_uri();?>/assets/img/slider/on10.jpg" alt="" width="280" height="280">
									<div class="product-content">
										<div class="small">Aziz Court, Agrabad, Chittagong</div>
									</div>
							   </div>
						</div>
					</div>
					<div class="owl-custom-navigation">
					  <div class="owl-nav">
						<div data-owl-prev class="owl-prev">Prew
							<i class=" fa fa-arrow-circle-left"></i>
						</div>
						<div data-owl-next class="owl-next">Next
							<i class=" fa fa-arrow-circle-right"></i>
						</div>
					  </div>
					</div>
				</div>
			</div>
		</section>
	    <!-- END  HOME -->
		<br>
	
	<!-- START ABOUT -->
		
		<section id="about" class="about_us section-padding">
			<div class="container">
				<div class="row text-center">
					<div class="section-title wow zoomIn">
						<h2>About Us</h2>
						<span></span>
					</div>	
                   <div class="col-md-6 sol-sm-12 col-xs-12 no-padding">
						<div class="skills">
							<div class="progress-bar-linear">
								<p class="progress-bar-text">Aluminium Fabrication
									<span>88/100</span>
								</p>
								<div class="progress-bar">
									<span data-percent="88"></span>
								</div>
							</div>
							<div class="progress-bar-linear">
								<p class="progress-bar-text">Aluminium Composite Pannel Works & Solution
									<span>85/100</span>
								</p>
								<div class="progress-bar">
									<span data-percent="85"></span>
								</div>
							</div>
							<div class="progress-bar-linear">
								<p class="progress-bar-text">Glass and ACP Canopy
									<span>92/100</span>
								</p>
								<div class="progress-bar">
									<span data-percent="92"></span>
								</div>
							</div>
							<div class="progress-bar-linear">
								<p class="progress-bar-text">Specialized Glass Work 
									<span>92/100</span>
								</p>
								<div class="progress-bar">
									<span data-percent="92"></span>
								</div>
							</div>
							<div class="progress-bar-linear">
								<p class="progress-bar-text">Support and Solutions 
									<span>99/100</span>
								</p>
								<div class="progress-bar">
									<span data-percent="92"></span>
								</div>
							</div>
						</div>
                    </div><!--- END COL -->					
                   <div class="col-md-6 col-sm-12 col-xs-12">
						<div class="about_content">
							<h1>We provide best <br> quality service from 1990</h1>
							<p>A good company should serve society as well as its Clients. To attain this goal, a Limited Company was floated in the name and style of Everest Eastern Ltd. On March 13, 1991 also with its Registered Office at 180, East Tejturi Bazar, Tejgaon, Dhaka. The idea behind a limited company is to expand the firms' technical, financial and organizational capacity. </p>
							<p class="mbtop">Engr. Md. Shah Suja Khan (Life Fellow) who had passed B.Sc. Engineering in Civil Department in 1974 from BUET is the founder Managing Director of the Company.</p>
							<p class="mbtop">M/s EVEREST EASTERN Ltd., is one of the largest architectural aluminium fabricator in Bangladesh. It's Voyage began from 1990 as a fabricator of aluminium doors, windows, curtain wall (unitized & stick system) etc. The company has shifted to its own premises at Momtaz Plaza (2nd Floor), House # 7, Road # 4, Dhanmondi R/A, Dhaka-1205 in February 2000 & started its journey and continued till to date.</p>
						</div>
                    </div><!--- END COL -->	
				</div><!-- END ROW  -->
			</div><!-- END CONTAINER  -->
		</section>	
	<!-- END ABOUT -->

	<!-- START COUNTER -->
		<section class="template_counter section-padding">
			<div class="container">
				<div class="row text-center">
					<div class="col-md-4 col-sm-6 col-xs-12">
						<div class="single_counter">
							<h1>38+</h1>
							<span></span>
							<h5>Complete Projects</h5>
						</div>
					</div><!-- END COL  -->
					<div class="col-md-4 col-sm-6 col-xs-12">
						<div class="single_counter">
							<h1>10+</h1>
							<span></span>
							<h5>On Going Projects</h5>
						</div>
					</div><!-- END COL  -->
					<div class="col-md-4 col-sm-6 col-xs-12">
						<div class="single_counter">
							<h1>40+</h1>
							<span></span>
							<h5>Happy Client</h5>
						</div>
					</div><!-- END COL  -->
					
				</div><!--END  ROW  -->
			</div><!-- END CONTAINER  -->
		</section>
	<!-- END COUNTER -->

	<!-- START SERVICE -->
		<section id="service" class="our_service">
			<div class="container">
				<div class="row text-center">
					<div class="section-title wow zoomIn">
						<h2>Our service</h2>
						<span></span>
					</div>
					<div class="col-md-4 col-sm-6 col-xs-12">
						<div class="single_service" style="background-image: url(assets/img/slider/1.jpg);  background-size:cover; background-position: center center;">		
							<div class="single_service_inner">
								<i class="fa fa-bullhorn"></i>
								<h4>Aluminium Fabrication</h4>
								<p>We Provide the best structural aluminium fabrication and solution.</p>
							</div>
						</div>
					</div><!--- END COL -->
					<div class="col-md-4 col-sm-6 col-xs-12">
						<div class="single_service" style="background-size:cover; background-position: center center;">	
							<div class="single_service_inner">
								<i class="fa fa-html5"></i>
								<h4>Composite Panel Works</h4>
								<p>We Provide the best aluminium composite panel works & solution.</p>
							</div>
						</div>
					</div><!--- END COL -->
					<div class="col-md-4 col-sm-6 col-xs-12">
						<div class="single_service" style="background-size:cover; background-position: center center;">		
							<div class="single_service_inner">
								<i class="fa fa-life-bouy"></i>
								<h4>Glass & ACP Canopy</h4>
								<p>We are expert in structural glass and ACP canopy.</p>
							</div>
						</div>
					</div><!--- END COL -->
					<div class="col-md-4 col-sm-6 col-xs-12">
						<div class="single_service" style="background-size:cover; background-position: center center;">		
							<div class="single_service_inner">
								<i class="fa fa-keyboard-o"></i>
								<h4>Glass Works</h4>
								<p>We give the best support for any kind of structural glass work.</p>
							</div>
						</div>
					</div><!--- END COL -->
					<div class="col-md-4 col-sm-6 col-xs-12">
						<div class="single_service" style="background-size:cover; background-position: center center;">		
							<div class="single_service_inner">
								<i class="fa fa-comments-o"></i>
								<h4>Free Support & Solutions</h4>
								<p>For any kind of support and solution please contact us.</p>
							</div>
						</div>
					</div><!--- END COL -->
					<div class="col-md-4 col-sm-6 col-xs-12">
						<div class="single_service" style="background-size:cover; background-position: center center;">		
							<div class="single_service_inner">
								<i class="fa fa-circle-o-notch"></i>
								<h4>Structural Development</h4>
								<p>We can assure you to give the best structural development support.</p>
							</div>
						</div>
					</div><!--- END COL -->
				</div><!--- END ROW -->
			</div><!--- END CONTAINER -->	
		</section>
	<!-- END SERVICE -->





	<!-- PORTFOLIO Start-->

		<div id="portfolio" class="template_portfolio">
			<div class="container">
				<div class="row text-center">
					<div class="section-title wow zoomIn">
						<h2>Accomplished Projects</h2>
						<span></span>
					</div>
					
					<div id="myBtnContainer" class="btnContainer">
					  <button class="btn active" onclick="filterSelection('all')">All Projects</button>
					  <button class="btn" onclick="filterSelection('complete')"> Complete Projects</button>
					  <button class="btn" onclick="filterSelection('ongoing')"> On Going Projects</button>
					</div>
					<br>

					<!-- Portfolio Gallery Grid -->
					 
						<?php 
							$args = array( 
									'post_type' => 'protfolio', 
									'posts_per_page' => -1
							    );

							$protfolios = new WP_Query( $args );

						?>	
						<?php 
							while ( $protfolios->have_posts() ) : $protfolios->the_post();
							$project_type = get_post_meta( get_the_ID(), '_everest_project_type', true );
							$featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); 
						?>
						  <div class="col-sm-6 col-md-4 col-xs-12 column <?php echo $project_type; ?>">
							<div id="myImg" class="thumbnails">
								<a href="<?php echo $featured_img_url ?>" rel="prettyPhoto[pp_gal]">
								<?php the_post_thumbnail('protfolio-post-thumbnail'); ?>
									<!-- <img src="#" alt="" style="width:250px; height:250px"> -->
								</a>
							  	<h4><?php the_title(); ?></h4>  
							  	<p><?php the_content(); ?></p>
							</div>
						  </div>
						 <?php endwhile; ?>
						 
					 

					<!-- Model  -->
					<div id="myModal" class="modal">
						  <span class="close">&times;</span>
						  <img class="modal-content" id="myImg">
						  <div id="caption"></div>
					</div>
			</div>
		</div>
		</div>

	<!-- PORTFOLIO End-->

		<!-- START TEAM -->
		<section id="team" class="template_team">
			<div class="container"> 
				<div class="row text-center"> 
					<div class="section-title wow zoomIn">
						<h2>Our Experts</h2>
						<span></span>
					</div>					
					<div class="col-md-3 col-sm-6">
						<div class="single_team"> 
							<img class="img-responsive" src="<?php echo get_template_directory_uri();?>/assets/img/team/member1.png" alt="">
							<h5 class="team-name">Engr. Md. Shah Suja Khan</h5>
							<div class="team-hover">
								<h5>Engr. Md. Shah Suja Khan</h5>
								<span>Managing Director</span>
								<p>Everest Eastern Ltd.</p>
								<ul class="social">
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
								</ul>
							</div>
						</div>
					</div><!--- END COL -->
					<div class="col-md-3 col-sm-6">
						<div class="single_team"> 
							<img class="img-responsive" src="<?php echo get_template_directory_uri();?>/assets/img/team/member2.png" alt="">
							<h5 class="team-name">Engr. Shah Md. Adnan Khan</h5>
							<div class="team-hover">
								<h5>Engr. Shah Md. Adnan Khan</h5>
								<span>Manager</span>
								<p>Everest Eastern Ltd.</p>	
								<ul class="social">
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
								</ul>
							</div>
						</div>
					</div><!--- END COL -->
					<div class="col-md-3 col-sm-6">
						<div class="single_team">
							<img class="img-responsive" src="<?php echo get_template_directory_uri();?>/assets/img/team/member3.png" alt="">
							<h5 class="team-name">Mrs. Latifa Akter</h5>
							<div class="team-hover">
								<h5>Mrs. Latifa Akter</h5>
								<span>Co-founder</span>
								<p>Everest Eastern Ltd.</p>
								<ul class="social">
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
								</ul>
							</div>
						</div>
					</div><!--- END COL -->
					<div class="col-md-3 col-sm-6">
						<div class="single_team"> 
							<img class="img-responsive" src="<?php echo get_template_directory_uri();?>/assets/img/team/member4.png" alt="">
							<h5 class="team-name">Dr. Shah Noor Shairmin</h5>
							<div class="team-hover">
								<h5>Dr. Shah Noor Shairmin</h5>
								<span>Co-founder</span>
								<p>Everest Eastern Ltd.</p>
								<ul class="social">
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
								</ul>
							</div>
						</div>
					</div><!--- END COL -->
				</div><!--- END ROW -->
			</div><!--- END CONTAINER -->
		</section>
		<!-- END TEAM -->
	
		<!-- START COMPANY PARTNER LOGO  -->
		<div class="partner-logo">
			<div class="container-logo wow zoomIn">
				<div class="row">
					<div class="col-md-12">
						<div class="partner  wow zoomIn fadeInRight">
							<a href="#"><img src="<?php echo get_template_directory_uri();?>/assets/img/logo/wordpress.jpg" alt="image"></a>
							<a href="#"><img src="<?php echo get_template_directory_uri();?>/assets/img/logo/joomla.jpg" alt="image"></a>
							<a href="#"><img src="<?php echo get_template_directory_uri();?>/assets/img/logo/magento.jpg" alt="image"></a>
							<a href="#"><img src="<?php echo get_template_directory_uri();?>/assets/img/logo/php.jpg" alt="image"></a>
							<a href="#"><img src="<?php echo get_template_directory_uri();?>/assets/img/logo/mautic.jpg" alt="image"></a>
						</div>
					</div><!-- END COL  -->
				</div><!--END  ROW  -->
			</div><!-- END CONTAINER  -->
		</div>
		<!-- END COMPANY PARTNER LOGO -->
		
		<!-- START CONTACT FORM AND MAP -->
		<section id="contact" class="contact_area section-padding">
			<div class="container">
				<div class="row text-center">
					<div class="section-title wow zoomIn">
						<h2>Contacts</h2>
						<span></span>
					</div>								
					<div class="col-md-6 col-sm-12 col-xs-12">
						<div class="contact">
							
							<?php echo do_shortcode('[contact-form-7 id="62" title="Contact Form"]');?>
						</div>
					</div>
					<!-- END COL -->	
					<div class="col-md-6 col-sm-12 col-xs-12">					
						<div id="map"></div>

					</div><!-- END COL -->						
				</div><!--- END ROW -->				
			</div><!--- END CONTAINER -->	
		</section>
		<!-- END CONTACT FORM  AND MAP -->

		<!-- START CONTACT ADDRESS -->
		<div class="contact-address section-padding">
			<div class="container">
				<div class="row text-center">
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="single_address">
							<i class="fa fa-phone"></i>
							<p>+880-2-9661171</p>
							<p>+880-2-8622371</p>
						</div>
					</div><!-- END COL  -->
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="single_address">
							<i class="fa fa-map-marker"></i>
							<p>Momtaz Plaza (2nd Floor),<br>House # 7, Road # 4, <br>Dhanmondi R/A, Dhaka-1205.</p>
						</div>
					</div><!-- END COL  -->
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="single_address">
							<i class="fa fa-envelope"></i>
							<p>eelbd@yahoo.com</p>
						</div>
					</div><!-- END COL  -->
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="single_address">
							<i class="fa fa-clock-o"></i>
							<p>Sun - Thu: 10.00 - 18.00</p>
							<p>Sat - Fri: 11.00 - 16.00</p>
						</div>
					</div><!-- END COL  -->
				</div><!--END  ROW  -->
			</div><!-- END CONTAINER  -->
		</div>
		<!-- END CONTACT ADDRESS -->
		
		<!-- START FOOTER -->
		<div class="footer">
			<div class="container">
				<div class="row">					
					<div class="col-md-6 col-sm-6 col-xs-12 wow zoomIn">
						<div class="copyright">
							<?php echo $eel['copy_text'];?>
						</div><!--- END FOOTER COPYRIGHT -->
					</div><!--- END COL -->		
					<div class="col-md-6 col-sm-6 col-xs-12 wow zoomIn">
						<div class="footer_menu">
							<ul>
								<li><a href="#about">About</a></li>
								<li><a href="#">Support</a></li>
								<li><a href="#service">Services</a></li>
								<li><a href="#contact">Contact</a></li>								
							</ul>
						</div>
					</div><!--- END COL -->			
				</div><!--- END ROW -->				
			</div><!--- END CONTAINER -->
		</div>
		<!-- END FOOTER -->									

<?php wp_footer();?>
    </body>
</html>